#ifndef TWEENABLEPARAMS_H
#define TWEENABLEPARAMS_H

enum class TweenableParams{X, Y, ALPHA, SCALE_X, SCALE_Y, ROTATION};

#endif