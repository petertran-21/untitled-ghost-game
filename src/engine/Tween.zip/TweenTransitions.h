#ifndef TWEENTRANSITIONS_H
#define TWEENTRANSITIONS_H

class TweenTransitions{
public:
    TweenTransitions();
    void applyTransition(double percentDone);
    void easeInOut(double percentDone);
};

#endif