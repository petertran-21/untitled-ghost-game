#include "TweenTransitions.h"

TweenTransitions::TweenTransitions(){

}

void TweenTransitions::applyTransition(double percentDone){

}

void TweenTransitions::easeInOut(double percentDone){
    
}
